Images of fibers in stem cells under stress.

stressFibers.mat, stressFibers.txt, stressFibers.csv, stressFibers.npy:
	Image data in various formats.

Data courtesy Andre Brown.

References:
	- A Zemel, F Rehfeldt, A E X Brown, D E Discher, S A Safran.
	  Nature Physics 6, 468--473 (2010)
	- A Zemel et al. J.  Phys.: Condens. Matter 22 194110. (2010)
