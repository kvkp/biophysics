Geographic locations of a set of incidents.
Data from http://bombsight.org/#14/51.4465/-0.0756

File incidents.mat contains:
	- incidents = (x,y) pairs describing map coordinates of each incident in
	  arbitrary units
	- referencepoints = (x,y) pairs with map coordinates of four reference
	  points in arbitrary units
	- place1, ... = names of reference points

Approximate scale is 44 m per unit.

incidents.csv, incidents.npy: incident data.
reference.csv, reference.npy: reference data.

incidents.xlsx, clusters.npz: incident and reference data in single file
