Stock market data.

File djiweekly.mat contains variable djiweekly with closing values of
Dow Jones Industrial Average on 4223 consecutive weeks.

Files djiweekly.csv and djiweekly.npy contain the same data.
