Jean Perrin's data on Brownian motion.

g26perrindata.csv
g26perrindata.mat
g26perrindata.npy

(x,y) values of endpoints of 508 random walks, in micrometers.

Data from J. Perrin, "Les Atomes."
